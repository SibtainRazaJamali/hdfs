package main

import (
	"html/template"
	"net/http"
)

func main() {
	formTemplate := template.Must(template.ParseFiles("new.html"))
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			formTemplate.Execute(w, nil)
			return
		}

		formTemplate.Execute(w, struct{ Success bool }{true})
	})
	http.ListenAndServe(":8080", nil)

}
