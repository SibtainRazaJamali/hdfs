package main

import (
	"fmt"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
)

type Slave struct {
	slaveName   string //name of slave
	isBusy      bool   //to check if a slave is busy or not
	isIterated  bool   //if a slave has performed searching we don't use it again for same task
	connAddress net.Conn
	task        string
}

var dataNodes []Slave
var replicaNodes []Slave

//this algorithm allocates task when a slave is free otherwise it waits for a slave to get free
func divideTask(password string) {
	// for slave in range(freeslaves):
	//if a slave has performed searching we don't ask it to search again
	//if a slave is busy we ask its replica node to do searching
	//if all the slaves are performing search we break the scheduling
	count := 0
	for {

		if count == 10 {
			break
		}
		for _, slave := range dataNodes {
			if slave.task != password {
				if slave.isBusy {
					tokenized := strings.Split(slave.slaveName, "_")
					replicaNode := "replica_" + tokenized[1]
					for _, replica := range replicaNodes {
						if replica.slaveName == replicaNode && replica.isBusy == false {
							replica.connAddress.Write([]byte(password))
							count++
							slave.task = password
							replica.task = password
							replica.isBusy = true
						}
					}
				} else {
					slave.connAddress.Write([]byte(password))
					slave.task = password
					slave.isBusy = true
					count++
				}
			}

		}

	}

}
func newClient(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.Error(w, "404 not found.", http.StatusNotFound)
		return
	}

	switch r.Method {
	case "GET":
		http.ServeFile(w, r, "passwords.html")
	case "POST":

		if err := r.ParseForm(); err != nil {
			fmt.Fprintf(w, "ParseForm() err: %v", err)
			return
		}
		password := r.FormValue("password")
		fmt.Fprintf(w, "<h1>%s</h1>", password)
	default:
		fmt.Fprintf(w, "Sorry, only GET and POST methods are supported.")
	}
}

func main() {

	var slavePort int
	var clientPort int
	if len(os.Args) < 3 {
		//fmt.Println("please provide port numbers for clients and slaves")
		clientPort = 9999 //default port for clients
		slavePort = 9998  //default port for slaves
	} else if len(os.Args) == 3 {
		slavePort, _ = strconv.Atoi(os.Args[1])
		clientPort, _ = strconv.Atoi(os.Args[2])
	}
	fmt.Println(clientPort)
	fmt.Println(slavePort)

	slaveListen, slaveError := net.Listen("tcp", fmt.Sprintf(":%d", slavePort)) //listening slaves on given port
	if slaveError != nil {
		fmt.Println("failed to listen slaves on given port")
	} else {
		fmt.Println("slaves can be registered on Port :" + strconv.Itoa(slavePort))
	}
	fmt.Println(slaveListen)
	http.HandleFunc("/", newClient)
	http.ListenAndServe(":"+strconv.Itoa(clientPort), nil)

}
