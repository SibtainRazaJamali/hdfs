package main

import (
	"fmt"
	"net"
	"io/ioutil"
	"log"
	"bufio"
	"time"
	"os"

)
func search(file string,password string) int {
  tempFile, err := os.Open(file)
	fmt.Println("searching File",file)
	if err!=nil{
		fmt.Println("Error",file)
	}
  defer tempFile.Close()
  scanner := bufio.NewScanner(tempFile)
  for scanner.Scan() {
      if password==scanner.Text(){
				//fmt.Println("found",file)
        return 1
      }
			if sharedVariable==1{
				break
			}


  }
	return 0
}
var sharedVariable int
var searchFlag int
func searchPassword(password string){
	files, _ := ioutil.ReadDir("./data_0")
	for _, file := range files {
		if sharedVariable==1{
			break
		}
		fname:="./data_0/"+file.Name()
		searchFlag=search(fname,password)
		fmt.Println("found",searchFlag)
		if searchFlag==1{
			break
		}
	}
}
func main() {
	conn, err := net.Dial("tcp", "localhost:2223")
	if err != nil {
		// handle error
	}
	fmt.Println("Registered To Server!!", conn.RemoteAddr())
	files, err := ioutil.ReadDir("./data_0")
	if err != nil {
		log.Fatal(err)
	}
	conn.Write([]byte("data_node_1"))
	time.Sleep(time.Millisecond * 10)
	fmt.Println("Sending List Of files To ", conn.RemoteAddr())
	for _, file := range files {

		conn.Write([]byte(file.Name()))
		time.Sleep(time.Millisecond * 10)
	}
	for {
		sharedVariable=0
		fmt.Println("Waiting for Tasks")
		recvdSlice := make([]byte, 100)
		n,_:=conn.Read(recvdSlice)
		if string(recvdSlice[0:n])=="abort"{
			sharedVariable=1
		} else{
			searchPassword(string(recvdSlice[0:n]))
			if searchFlag==1{
				conn.Write([]byte("Node 1 Found password"))
			}

			fmt.Println(string(recvdSlice))
		}


	}


}
