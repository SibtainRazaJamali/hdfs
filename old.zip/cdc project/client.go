package main

import (
	"fmt"
	"net"
	"os"
	"flag"
)

func main() {


	search := flag.String("searchText", "###", "string")
	serverAddress:=flag.String("server","localhost:2222","string")
	flag.Parse()
	if len(os.Args)<2{
		fmt.Println("searchText argument is compulsory")
		os.Exit(-1)
	}

	fmt.Println("searchText:", *search)
  fmt.Println("server", *serverAddress)
	conn, err := net.Dial("tcp", *serverAddress)
	if err != nil {
		// handle error
	}
	fmt.Println("Connected to Server at ", conn.RemoteAddr())
	conn.Write([]byte(*search))
	fmt.Println("waiting for server response")
	recvdSlice := make([]byte, 11)
	conn.Read(recvdSlice)
	fmt.Println(string(recvdSlice))

}
