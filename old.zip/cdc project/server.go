package main
import (
  "fmt"
  "os"
  "log"
  "net"
  "strconv"
  //"strings"
  //"time"

)
type Slave struct {
  Name string
  listOfFiles [7]string
  slaveAddress net.Conn
  busy int
}

//var clients = []Client
var registeredSlaves []Slave

func scheduleTask(searchText string){
  if []rune(string(searchText[0]))[0]<65{
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_1" || s.Name=="replica_node_1"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  }  else if []rune(string(searchText[0]))[0]>=65 && []rune(string(searchText[0]))[0]<71{
    //data_node1,2
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_2" || s.Name=="replica_node_2"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
      if s.Name=="data_node_1" || s.Name=="replica_node_1"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  } else if []rune(string(searchText[0]))[0]>=71 && []rune(string(searchText[0]))[0]<76{
    //data_node2,3
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_2" || s.Name=="replica_node_2"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
      if s.Name=="data_node_3" || s.Name=="replica_node_3"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  } else if []rune(string(searchText[0]))[0]>=76 && []rune(string(searchText[0]))[0]<83{
    //data_node3,4
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_4" || s.Name=="replica_node_4"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
      if s.Name=="data_node_3" || s.Name=="replica_node_3"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  } else if []rune(string(searchText[0]))[0]>=83 && []rune(string(searchText[0]))[0]<90{
    //data_node4,5
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_4" || s.Name=="replica_node_4"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
      if s.Name=="data_node_5" || s.Name=="replica_node_5"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  } else if []rune(string(searchText[0]))[0]>=98 && []rune(string(searchText[0]))[0]<103{
    //data_node2,3
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_2" || s.Name=="replica_node_2"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
      if s.Name=="data_node_3" || s.Name=="replica_node_3"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  } else if []rune(string(searchText[0]))[0]>=103 && []rune(string(searchText[0]))[0]<108{
      //data_node3,4
      for _,s :=range registeredSlaves{
        if s.Name=="data_node_4" || s.Name=="replica_node_4"{
          s.slaveAddress.Write([]byte(searchText))
        /*  recvdSlice := make([]byte, 100)
      		n,_:=s.slaveAddress.Read(recvdSlice)
          fmt.Println(string(recvdSlice[0:n]))*/
        }
        if s.Name=="data_node_3" || s.Name=="replica_node_3"{
          s.slaveAddress.Write([]byte(searchText))
          /*recvdSlice := make([]byte, 100)
      		n,_:=s.slaveAddress.Read(recvdSlice)
          fmt.Println(string(recvdSlice[0:n]))*/
        }
      }
  } else if []rune(string(searchText[0]))[0]>=108 && []rune(string(searchText[0]))[0]<115{
      //data_node,4,5
      for _,s :=range registeredSlaves{
        if s.Name=="data_node_4" || s.Name=="replica_node_4"{
          s.slaveAddress.Write([]byte(searchText))
          /*recvdSlice := make([]byte, 100)
      		n,_:=s.slaveAddress.Read(recvdSlice)
          fmt.Println(string(recvdSlice[0:n]))*/
        }
        if s.Name=="data_node_5" || s.Name=="replica_node_5"{
          s.slaveAddress.Write([]byte(searchText))
          /*recvdSlice := make([]byte, 100)
      		n,_:=s.slaveAddress.Read(recvdSlice)
          fmt.Println(string(recvdSlice[0:n]))*/
        }
      }
  } else if []rune(string(searchText[0]))[0]>=115 && []rune(string(searchText[0]))[0]<=122{
    for _,s :=range registeredSlaves{
      if s.Name=="data_node_5" || s.Name=="replica_node_5"{
        s.slaveAddress.Write([]byte(searchText))
        /*recvdSlice := make([]byte, 100)
    		n,_:=s.slaveAddress.Read(recvdSlice)
        fmt.Println(string(recvdSlice[0:n]))*/
      }
    }
  } else{
    fmt.Println("Not fit in Ascii")
  }
}

func acceptClients(l net.Listener){
  defer l.Close()
  for{
    conn,err:=l.Accept()
    if err!=nil{
      log.Println(err)
      continue
    }
    //fmt.Println("New client found!")
    go handleClients(conn)
  }
}
func acceptSlave(l net.Listener){
  defer l.Close()
  for{
    conn,err:=l.Accept()
    if err!=nil{
      log.Println(err)
      continue
    }
    fmt.Println("New Slave Registered!")
    go handleSlaves(conn)
  }
}
func handleClients(c net.Conn){
  fmt.Println("Welcome Client")
  buf := make([]byte, 4096)
  n, err := c.Read(buf)
  if err!=nil || n==0{

  }
  password:=string(buf[0:n])
  go scheduleTask(password)

}
func handleSlaves(c net.Conn){
  //fmt.Println("New Slaves Handled!")
  var slaveName string
  var fileNames [7]string
  messageCount:=0
  //remoteAddr:=c.RemoteAddr().String()
  var deleteIndex int
	for {
    buf := make([]byte, 1000)
		n, err := c.Read(buf)
		if err != nil || n == 0 {
      for index,slave :=range registeredSlaves{
        if slave.Name==slaveName{
          deleteIndex=index
          break
        }
      }
      registeredSlaves[deleteIndex]=registeredSlaves[len(registeredSlaves)-1]
      registeredSlaves=registeredSlaves[:len(registeredSlaves)-1]

      fmt.Println("Slave died : ",slaveName)
			c.Close()
			break
		}
    fmt.Println(string(buf[0:n]))
    if messageCount==0{
        slaveName=string(buf[0:n])
        messageCount++
    }   else if messageCount<8{
      fileNames[messageCount-1]=string(buf[0:n])
      messageCount++
    }

    if (messageCount==8){
      newSlave := Slave{Name: slaveName, listOfFiles: fileNames,slaveAddress:c}
      registeredSlaves=append(registeredSlaves,newSlave)
      //fmt.Println(registeredSlaves)
    }
		//fmt.Println(string(buf[0:n]))
		}
}
func main(){
  var clientPortNumber int
  var slavePortNumber int
  if len(os.Args)<3{
    clientPortNumber=2222
    slavePortNumber=2223
  }  else {
    clientPortNumber,_=strconv.Atoi(os.Args[1])
    slavePortNumber,_=strconv.Atoi(os.Args[2])
  }

  clientLn,clErr:=net.Listen("tcp", fmt.Sprintf(":%d", clientPortNumber))

  if clErr != nil {
		fmt.Println("Failed to listen on client port Number")
	}  else{
    fmt.Printf("Server is listening to Clients on Port:%d\n",clientPortNumber)
  }
  slaveLn,slaveErr:=net.Listen("tcp", fmt.Sprintf(":%d", slavePortNumber))
  if slaveErr != nil {
		fmt.Println("Failed to listen on client port Number")
	}  else{
    fmt.Printf("Server is listening to Slaves on Port:%d\n",slavePortNumber)
  }
  go acceptClients(clientLn)
  acceptSlave(slaveLn)

}
