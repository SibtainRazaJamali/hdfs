package readFiles
import (
   "bufio"
   "net"

)
func search(c net.Conn,file string,password string) int{
  file, _ := os.Open(file)
  defer file.Close()
  scanner := bufio.NewScanner(file)
  for scanner.Scan() {
      if password==scanner.Text().String(){
        return 1
      }


  }
}
func readFiles(c net.Conn,file string,password string) int{
  recvdSlice := make([]byte, 11)
  conn.Read(recvdSlice)
  if string(recvdSlice)=="Abort"{
    return 0
  }
  go search(c,file,password)


}
